##Basic Arduino Serial Commucation##

Read the data and use String to Int to bool for ON or OFF