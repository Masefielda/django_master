=============
iot-dashboard
=============

 - Language : Ruby
 - Framework: Dashboard

![](https://raw.github.com/gmszone/iot-dashboard/master/doc/screenshot.png)

##How to Run##

   bundle install
   dashing start
